Download and install NUnit from 

http://www.nunit.org/


