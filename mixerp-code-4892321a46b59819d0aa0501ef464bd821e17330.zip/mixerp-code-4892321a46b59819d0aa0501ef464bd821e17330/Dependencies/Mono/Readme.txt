MixERP targets Mono Profile 3.2.3 instead of .NET Framekwork 4.5. This means that you will have to adjust your development environment accordingly.

How to Target Mono Profile 3.2.3 on Visual Studio 2010/2012/2013?

Copy the directory "Profile" and paste it to either of the following locations:

On 32-bit Windows --> C:\Program Files\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.5
On 64-bit Windows --> C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.5

