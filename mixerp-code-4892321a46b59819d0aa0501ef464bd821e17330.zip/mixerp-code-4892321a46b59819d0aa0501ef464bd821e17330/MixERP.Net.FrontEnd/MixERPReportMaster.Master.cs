﻿using System;
using System.Web.UI;

namespace MixERP.Net.FrontEnd
{
    public partial class MixERPReportMaster : MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}