﻿using System;

namespace MixERP.Net.FrontEnd
{
    public partial class MixERPBlankMaster : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}