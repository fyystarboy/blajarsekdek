﻿using System;

namespace MixERP.Net.FrontEnd.Sales.Confirmation
{
    public partial class ReportSalesOrder : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}