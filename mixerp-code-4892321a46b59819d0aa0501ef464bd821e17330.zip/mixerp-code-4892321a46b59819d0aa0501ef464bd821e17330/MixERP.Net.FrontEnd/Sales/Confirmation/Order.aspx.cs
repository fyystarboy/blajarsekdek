﻿using System;

namespace MixERP.Net.FrontEnd.Sales.Confirmation
{
    public partial class Order : BusinessLayer.MixERPWebpage
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}