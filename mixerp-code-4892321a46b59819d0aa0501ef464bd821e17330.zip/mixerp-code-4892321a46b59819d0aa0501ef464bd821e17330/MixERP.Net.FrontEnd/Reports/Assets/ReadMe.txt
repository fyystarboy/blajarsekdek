﻿Two types of named parameters can be used in the header:

1. Session parameter: see MixERP.Net.BusinessLayer.Security.SetSession() for more info.
2. Resource parameter: see App_GlobalResources directory.