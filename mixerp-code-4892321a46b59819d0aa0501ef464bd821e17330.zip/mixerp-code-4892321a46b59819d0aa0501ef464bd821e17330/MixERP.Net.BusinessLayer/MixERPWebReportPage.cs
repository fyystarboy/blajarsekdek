﻿namespace MixERP.Net.BusinessLayer
{
    public class MixERPWebReportPage:MixERPWebpage
    {
    }
}
