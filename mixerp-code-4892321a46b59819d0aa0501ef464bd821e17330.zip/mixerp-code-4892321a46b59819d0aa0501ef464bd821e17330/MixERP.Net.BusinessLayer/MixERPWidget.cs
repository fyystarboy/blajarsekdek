﻿using System.Web.UI;

namespace MixERP.Net.BusinessLayer
{
    public class MixERPWidget : UserControl
    {
    }
}
