﻿namespace MixERP.Net.Common.Models.Office
{
    public class Role
    {
        public int RoleId { get; set; }
        //Todo
    }
}
