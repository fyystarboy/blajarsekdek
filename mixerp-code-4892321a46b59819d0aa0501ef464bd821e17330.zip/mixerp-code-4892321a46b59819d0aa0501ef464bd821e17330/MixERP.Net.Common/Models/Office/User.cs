﻿namespace MixERP.Net.Common.Models.Office
{
    public class User
    {
        public int UserId { get; set; }
        //Todo
    }
}
